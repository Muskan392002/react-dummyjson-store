# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

## Expanding the ESLint configuration

If you are developing a production application, we recommend using TypeScript with type-aware lint rules enabled. Check out the [TS template](https://github.com/vitejs/vite/tree/main/packages/create-vite/template-react-ts) for information on how to integrate TypeScript and [`typescript-eslint`](https://typescript-eslint.io) in your project.


# DummyJSON E-commerce Website

An e-commerce web application built using the [DummyJSON API](https://dummyjson.com/) to simulate real e-commerce features like browsing products, viewing details, and managing a shopping cart. Perfect for learning frontend development and API integration.

## Features

✅ Product listing page  
✅ Product detail page  
✅ Search/filter products  
✅ Add/remove items from cart  
✅ Responsive design

## Tech Stack

- HTML / CSS / JavaScript  
* React
- DummyJSON API

## Installation

1. Clone the repository:

```bash
git clone https://github.com/your-username/dummyjson-ecommerce.git
cd dummyjson-ecommerce

