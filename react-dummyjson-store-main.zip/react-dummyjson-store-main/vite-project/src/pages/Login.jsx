import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext"; // useAuth hook, not direct context

export default function Login() {
  const { login } = useAuth(); // use login function from context
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    console.log("Trying to log in with:", { username, password });

    try {
      const res = await fetch("https://dummyjson.com/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: username.trim(), // trim to avoid space issues
          password,
        }),
      });

      const data = await res.json();
      console.log("Response from API:", data);

      if (!res.ok) {
        throw new Error(data.message || "Login failed");
      }

      login(data); // save user in context
      navigate("/"); // redirect to home
    } catch (error) {
      alert("Invalid username or password");
    }
  };

  return (
    <div style={{ padding: "2rem" }}>
      <h2>Login</h2>
      <form
        onSubmit={handleLogin}
        style={{ display: "flex", flexDirection: "column", maxWidth: "300px" }}
      >
        <input
          type="text"
          placeholder="Username"
          value={username}
          required
          onChange={(e) => setUsername(e.target.value)}
          style={{ marginBottom: "1rem", padding: "0.5rem" }}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          required
          onChange={(e) => setPassword(e.target.value)}
          style={{ marginBottom: "1rem", padding: "0.5rem" }}
        />
        <button
          type="submit"
          style={{ padding: "0.5rem", backgroundColor: "#333", color: "#fff" }}
        >
          Login
        </button>
      </form>
    </div>
  );
}
