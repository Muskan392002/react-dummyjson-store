// src/pages/Cart.jsx
import React from "react";
import { useCart } from "../context/CartContext";

export default function Cart() {
  const {
    cartItems,
    removeFromCart,
    increaseQty,
    decreaseQty,
    getTotalPrice,
  } = useCart();

  if (cartItems.length === 0) {
    return <p style={{ padding: "2rem" }}>Your cart is empty.</p>;
  }

  return (
    <div style={{ padding: "2rem" }}>
      <h2>Your Cart</h2>
      <ul>
        {cartItems.map((item) => (
          <li key={item.id} style={{ marginBottom: "1rem" }}>
            <img src={item.thumbnail} alt={item.title} style={{ width: "100px" }} />
            <p>{item.title}</p>
            <p>
              ${item.price} x {item.quantity} = ${item.price * item.quantity}
            </p>
            <button onClick={() => decreaseQty(item.id)}>-</button>
            <button onClick={() => increaseQty(item.id)}>+</button>
            <button
              onClick={() => removeFromCart(item.id)}
              style={{ background: "red", color: "#fff", marginLeft: "0.5rem" }}
            >
              Remove
            </button>
          </li>
        ))}
      </ul>
      <h3>Total: ${getTotalPrice()}</h3>
    </div>
  );
}
