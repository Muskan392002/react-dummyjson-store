// src/pages/Home.jsx
import React, { useEffect, useState } from 'react';
import { fetchProducts } from '../services/productAPI';
import ProductCard from '../components/ProductCard';
import { useCart } from '../context/CartContext';

export default function Home() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  const { addToCart } = useCart();

  useEffect(() => {
    const getData = async () => {
      try {
        const data = await fetchProducts();
        setProducts(data.products || []);
        setCategories(data.products.map((p) => p.category));
        setLoading(false);
      } catch (error) {
        console.error('Error fetching products:', error);
        setLoading(false);
      }
    };

    getData();
  }, []);

  // Filter logic
  const filteredProducts = products.filter((product) => {
    const matchCategory = selectedCategory ? product.category === selectedCategory : true;
    const matchSearch = product.title.toLowerCase().includes(searchTerm.toLowerCase());
    return matchCategory && matchSearch;
  });

  if (loading) return <p style={{ padding: '2rem' }}>Loading...</p>;

  return (
    <div style={{ padding: '2rem' }}>
      <h1>All Products</h1>

      {/* Search Input */}
      <input
        type="text"
        placeholder="Search products..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        style={{ padding: '0.5rem', marginBottom: '1rem', width: '100%', maxWidth: '400px' }}
      />

      {/* Category Filter */}
      <select
        onChange={(e) => setSelectedCategory(e.target.value)}
        style={{ padding: '0.5rem', marginBottom: '1rem' }}
      >
        <option value="">All Categories</option>
        {Array.isArray(categories) &&
          [...new Set(categories)].map((cat, index) => (
            <option key={index} value={cat}>
              {typeof cat === 'string'
                ? cat.charAt(0).toUpperCase() + cat.slice(1)
                : 'Unknown'}
            </option>
          ))}
      </select>

      {/* Product Grid */}
      <div className="product-grid" style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem' }}>
        {filteredProducts.length > 0 ? (
          filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} addToCart={addToCart} />
          ))
        ) : (
          <p>No matching products found.</p>
        )}
      </div>
    </div>
  );
}
