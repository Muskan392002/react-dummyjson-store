// src/services/productAPI.js

// Fetch all products
export async function fetchProducts() {
  const res = await fetch('https://dummyjson.com/products');
  const data = await res.json();
  return data; // contains { products: [...] }
}

// Fetch single product by ID
export async function fetchProductById(id) {
  const res = await fetch(`https://dummyjson.com/products/${id}`);
  const data = await res.json();
  return data; // single product object
}

// Fetch all available categories
export async function fetchCategories() {
  const res = await fetch('https://dummyjson.com/products/categories');
  const data = await res.json();
  return data; // array of category strings
}

// Fetch products by selected category
export async function fetchProductsByCategory(category) {
  const res = await fetch(`https://dummyjson.com/products/category/${category}`);
  const data = await res.json();
  return data; // contains { products: [...] }
}
