import React from 'react';
import { useNavigate } from 'react-router-dom';
import './ProductCard.css';

export default function ProductCard({ product }) {
  const navigate = useNavigate();
  return (
    <div className="card">
      <img src={product.thumbnail} alt={product.title} className="product-image" />
      <h2 className="product-title">{product.title}</h2>
      <p className="product-price">${product.price}</p>
      <button className="view-btn" onClick={() => navigate(`/product/${product.id}`)}>View Details</button>
    </div>
  );
}