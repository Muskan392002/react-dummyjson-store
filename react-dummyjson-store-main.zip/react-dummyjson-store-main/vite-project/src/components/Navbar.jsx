import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const { cartItems } = useCart();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <nav style={{ padding: "1rem", background: "#f5f5f5", display: "flex", justifyContent: "space-between" }}>
      <div>
        <Link to="/" style={{ marginRight: "1rem" }}>Home</Link>
        <Link to="/cart">Cart ({cartItems.length})</Link>
      </div>
      {user && (
        <button onClick={handleLogout} style={{ background: "tomato", color: "#fff", border: "none", padding: "0.5rem 1rem" }}>
          Logout
        </button>
      )}
    </nav>
  );
}
